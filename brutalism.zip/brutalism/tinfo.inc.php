<?php
/**
 * @Created by          : Waris Agung Widodo (ido.alit@gmail.com)
 * @Date                : 2020-01-02 15:12
 * @File name           : tinfo.inc.php
 */

$sysconf['template']['base'] = 'php';
$sysconf['template']['responsive'] = false;

$sysconf['template']['classic_library_subname'] = 0;
$sysconf['template']['classic_popular_collection'] = 1;
$sysconf['template']['classic_popular_collection_item'] = 6;
$sysconf['template']['classic_new_collection'] = 1;
$sysconf['template']['classic_new_collection_item'] = 6;
$sysconf['template']['classic_top_reader'] = 1;
$sysconf['template']['classic_suggestion'] = 1;
$sysconf['template']['classic_map'] = 1;
$sysconf['template']['classic_map_link'] = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.288723306273!2d106.80038831428296!3d-6.225610995493402!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f14efd9abf05%3A0x1659580cc6981749!2sPerpustakaan+Kemendikbud!5e0!3m2!1sid!2sid!4v1516601731218';
$sysconf['template']['classic_map_desc'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et nunc mi. Donec vehicula turpis a quam venenatis posuere. Aliquam nibh lectus, gravida et leo sit amet, dignissim dapibus mauris.<br>Telp. (021) 9172638<br>Fax. (021) 9172638<br>';
$sysconf['template']['classic_fb_link'] = 'https://www.facebook.com/groups/senayan.slims';
$sysconf['template']['classic_twitter_link'] = 'https://twitter.com/slims_official';
$sysconf['template']['classic_youtube_link'] = 'https://youtube.com';
$sysconf['template']['classic_instagram_link'] = 'https://instagram.com/slims.sdc';
$sysconf['template']['visitor_log_voice'] = 1;
$sysconf['template']['classic_footer_about_us'] = <<<HTML
<p>As a complete Library Management System, SLiMS (Senayan Library Management System) has many features that will help libraries and librarians to do their job easily 
and quickly. Follow <a target="_blank" href="https://slims.web.id/web/pages/about/">this link</a> to show some features provided by SLiMS.</p>
HTML;
$sysconf['template']['brutal_accent_color'] = 'yellow';
$sysconf['template']['brutal_accent_custom'] = '#ffe600';
$sysconf['template']['brutal_bg_pattern'] = 'dots';
$sysconf['template']['brutal_bg_custom'] = '';
$sysconf['template']['brutal_marquee_enable'] = 1;
$sysconf['template']['brutal_marquee_source'] = 'biblio_new';
$sysconf['template']['brutal_marquee_item_count'] = 10;
$sysconf['template']['brutal_marquee_custom_text'] = 'SENAYAN LIBRARY MANAGEMENT SYSTEM | OPEN ACCESS CATALOG | BROWSE BOOKS, PAPERS & JOURNALS | KNOWLEDGE IS NOT A PRIVILEGE | NO COMPROMISE DESIGN | READ MORE EVERY DAY';
$sysconf['template']['brutal_hero_enable'] = 1;
$sysconf['template']['brutal_hero_badges'] = '★ OPEN SOURCE OPAC | ✦ DIGITAL ARCHIVE | ● RAW KNOWLEDGE';
$sysconf['template']['brutal_hero_title'] = 'SEARCH. DISCOVER.';
$sysconf['template']['brutal_hero_highlight'] = 'CONQUER.';
$sysconf['template']['brutal_hero_sub'] = 'Pusat khazanah pustaka, naskah riset, dan koleksi ilmu pengetahuan tanpa sekat. Temukan ribuan referensi dalam genggaman.';

$sysconf['template']['option']['brutalism'] = [
    'accent_color' => [
        'dbfield' => 'brutal_accent_color',
        'label' => __('Warna Aksen Utama (Tema)'),
        'type' => 'dropdown',
        'default' => 'yellow',
        'data' => [
            ['yellow', __('Kuning Brutalis / Yellow Neon (Default)')],
            ['cyan', __('Cyan / Biru Muda Neon Cyberpunk')],
            ['pink', __('Hot Pink / Neon Magenta')],
            ['lime', __('Toxic Lime / Hijau Neon Kontras')],
            ['orange', __('Vivid Orange / Oranye Menyala')],
            ['purple', __('Electric Purple / Ungu')],
            ['red', __('Radical Red / Merah Berani')],
            ['blue', __('Electric Blue / Biru')],
            ['custom', __('Kustom / Input Kode Hex Sendiri')],
        ]
    ],
    'accent_custom' => [
        'dbfield' => 'brutal_accent_custom',
        'label' => __('Warna Aksen Kustom (Jika memilih Kustom di atas)'),
        'type' => 'text',
        'class' => 'colorpicker',
        'default' => '#ffe600',
        'width' => '30',
        'max' => 20
    ],
    'bg_pattern' => [
        'dbfield' => 'brutal_bg_pattern',
        'label' => __('Motif Pattern Background'),
        'type' => 'dropdown',
        'default' => 'dots',
        'data' => [
            ['dots', __('Dot Matrix / Titik-titik Brutalis (Default)')],
            ['grid', __('Graph Grid / Kotak-kotak Buku Grafis')],
            ['stripes', __('Diagonal Stripes / Garis Miring')],
            ['cross', __('Cross / Plus Matrix')],
            ['none', __('Clean / Polos (Tanpa Motif)')],
        ]
    ],
    'bg_custom' => [
        'dbfield' => 'brutal_bg_custom',
        'label' => __('Warna Background Dasar (Kosongkan jika mengikuti preset tema)'),
        'type' => 'text',
        'class' => 'colorpicker',
        'default' => '',
        'width' => '30',
        'max' => 20
    ],
    'responsive' => [
        'dbfield' => 'responsive',
        'label' => __('Enable this theme for mobile?'),
        'type' => 'dropdown',
        'default' => 0,
        'data' => [
            [1, __('Yes, please!')],
            [0, __('No, I want use lighweight theme')]
        ]
    ],
    'subtitle' => [
        'dbfield' => 'classic_library_subname',
        'label' => __('Library Sub Name'),
        'type' => 'dropdown',
        'default' => 0,
        'data' => [
            [1, __('Show')],
            [0, __('Hide')]
        ]
    ],
    'popular-collection' => [
        'dbfield' => 'classic_popular_collection',
        'label' => __('Popular Collection'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Show')],
            [0, __('Hide')]
        ]
    ],
    'popular-collection-item' => [
        'dbfield' => 'classic_popular_collection_item',
        'label' => __('Popular Items'),
        'type' => 'text',
        'default' => 6
    ],
    'new-collection' => [
        'dbfield' => 'classic_new_collection',
        'label' => __('New Collection'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Show')],
            [0, __('Hide')]
        ]
    ],
    'new-collection-item' => [
        'dbfield' => 'classic_new_collection_item',
        'label' => __('New Items'),
        'type' => 'text',
        'default' => 6
    ],
    'top-reader' => [
        'dbfield' => 'classic_top_reader',
        'label' => __('Top Reader'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Show')],
            [0, __('Hide')]
        ]
    ],
    'suggestion' => [
        'dbfield' => 'classic_suggestion',
        'label' => __('Suggestion'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Show')],
            [0, __('Hide')]
        ]
    ],
    'map' => [
        'dbfield' => 'classic_map',
        'label' => __('Map'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Show')],
            [0, __('Hide')]
        ]
    ],
    'map-link' => [
        'dbfield' => 'classic_map_link',
        'label' => __('Map URL'),
        'type' => 'longtext',
        'default' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.288723306273!2d106.80038831428296!3d-6.225610995493402!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f14efd9abf05%3A0x1659580cc6981749!2sPerpustakaan+Kemendikbud!5e0!3m2!1sid!2sid!4v1516601731218',
        'width' => '100',
        'max' => 1000
    ],
    'map-desc' => [
        'dbfield' => 'classic_map_desc',
        'label' => __('Map Description'),
        'type' => 'ckeditor',
        'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et nunc mi. Donec vehicula turpis a quam venenatis posuere. Aliquam nibh lectus, gravida et leo sit amet, dignissim dapibus mauris.<br>Telp. (021) 9172638<br>Fax. (021) 9172638<br>',
    ],
    'fb-link' => [
        'dbfield' => 'classic_fb_link',
        'label' => __('Facebook URL'),
        'type' => 'longtext',
        'default' => 'https://www.facebook.com/groups/senayan.slims',
        'width' => '100',
        'max' => 1000
    ],
    'twitter-link' => [
        'dbfield' => 'classic_twitter_link',
        'label' => __('Twitter URL'),
        'type' => 'longtext',
        'default' => 'https://twitter.com/slims_official',
        'width' => '100',
        'max' => 1000
    ],
    'youtube-link' => [
        'dbfield' => 'classic_youtube_link',
        'label' => __('Youtube URL'),
        'type' => 'longtext',
        'default' => 'https://youtube.com',
        'width' => '100',
        'max' => 1000
    ],
    'instagram-link' => [
        'dbfield' => 'classic_instagram_link',
        'label' => __('Instagram URL'),
        'type' => 'longtext',
        'default' => 'https://www.instagram.com/slims.sdc',
        'width' => '100',
        'max' => 1000
    ],
    'footer_about_us' => [
        'dbfield' => 'classic_footer_about_us',
        'label' => __('Footer About Us'),
        'type' => 'ckeditor',
        'default' => '<p>As a complete Library Management System, SLiMS (Senayan Library Management System) has many features that will help libraries and librarians to do their job easily and quickly. Follow <a target="_blank" href="https://slims.web.id/web/pages/about/">this link</a> to show some features provided by SLiMS.</p>',
    ],
    'visitor_voice' => [
        'dbfield' => 'visitor_log_voice',
        'label' => __('Visitor log voice'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Enable')],
            [0, __('Disable')]
        ]
    ],
    'marquee_enable' => [
        'dbfield' => 'brutal_marquee_enable',
        'label' => __('Enable Marquee Banner'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Show / Tampilkan')],
            [0, __('Hide / Sembunyikan')]
        ]
    ],
    'marquee_source' => [
        'dbfield' => 'brutal_marquee_source',
        'label' => __('Marquee Source / Sumber Konten'),
        'type' => 'dropdown',
        'default' => 'biblio_new',
        'data' => [
            ['biblio_new', __('Data Buku / Koleksi Terbaru')],
            ['news', __('Data Berita / Informasi Terbaru')],
            ['biblio_popular', __('Data Koleksi Terpopuler')],
            ['slogan', __('Slogan Brutalist & Filosofi SLiMS (Preset)')],
            ['custom', __('Teks Kustom Manual')]
        ]
    ],
    'marquee_item_count' => [
        'dbfield' => 'brutal_marquee_item_count',
        'label' => __('Marquee Items Count / Jumlah Data'),
        'type' => 'numeric',
        'default' => 10,
        'width' => '30',
        'max' => 3
    ],
    'marquee_custom_text' => [
        'dbfield' => 'brutal_marquee_custom_text',
        'label' => __('Custom Text (Pisahkan dengan tanda | jika pilih Teks Kustom Manual)'),
        'type' => 'longtext',
        'default' => 'SENAYAN LIBRARY MANAGEMENT SYSTEM | OPEN ACCESS CATALOG | BROWSE BOOKS, PAPERS & JOURNALS | KNOWLEDGE IS NOT A PRIVILEGE | NO COMPROMISE DESIGN | READ MORE EVERY DAY',
        'width' => '100',
        'max' => 1000
    ],
    'hero_enable' => [
        'dbfield' => 'brutal_hero_enable',
        'label' => __('Tampilkan Hero Billboard'),
        'type' => 'dropdown',
        'default' => 1,
        'data' => [
            [1, __('Show / Tampilkan')],
            [0, __('Hide / Sembunyikan')]
        ]
    ],
    'hero_badges' => [
        'dbfield' => 'brutal_hero_badges',
        'label' => __('Hero Stickers / Badges (Pisahkan dengan tanda | )'),
        'type' => 'text',
        'default' => '★ OPEN SOURCE OPAC | ✦ DIGITAL ARCHIVE | ● RAW KNOWLEDGE',
        'width' => '100',
        'max' => 255
    ],
    'hero_title' => [
        'dbfield' => 'brutal_hero_title',
        'label' => __('Judul Utama Hero Billboard'),
        'type' => 'text',
        'default' => 'SEARCH. DISCOVER.',
        'width' => '100',
        'max' => 255
    ],
    'hero_highlight' => [
        'dbfield' => 'brutal_hero_highlight',
        'label' => __('Kata Sorotan Hero (Garis Bawah Kuning Tebal)'),
        'type' => 'text',
        'default' => 'CONQUER.',
        'width' => '50',
        'max' => 100
    ],
    'hero_sub' => [
        'dbfield' => 'brutal_hero_sub',
        'label' => __('Deskripsi Subtitle Hero Billboard'),
        'type' => 'longtext',
        'default' => 'Pusat khazanah pustaka, naskah riset, dan koleksi ilmu pengetahuan tanpa sekat. Temukan ribuan referensi dalam genggaman.',
        'width' => '100',
        'max' => 1000
    ],
];

if (isset($sysconf['template']['theme']) && $sysconf['template']['theme'] !== 'brutalism') {
    $sysconf['template']['option'][$sysconf['template']['theme']] = &$sysconf['template']['option']['brutalism'];
}
