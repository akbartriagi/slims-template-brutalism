<?php
/**
 * @Created by          : Waris Agung Widodo (ido.alit@gmail.com)
 * @Date                : 2019-01-31 17:30
 * @File name           : news_template.php
 * @Modified for        : Neo-Brutalism Theme
 */

function news_list_tpl($title, $path, $date, $summary) {
  global $sysconf;
  if (isset($_COOKIE['select_lang'])) $sysconf['default_lang'] = trim(strip_tags($_COOKIE['select_lang']));
  ?>

  <div class="brutal-section-box mb-4">
      <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="brutal-code-stamp"><i class="far fa-clock mr-1"></i> <?= \Carbon\Carbon::parse($date)->locale($sysconf['default_lang'])->isoFormat('dddd, LL') ?></span>
          <span class="brutal-badge-pill brutal-pill-yellow">[ NEWSLETTER ]</span>
      </div>
      <h3 class="brutal-heading-h3 my-3"><?php echo $title ?></h3>
      <p class="brutal-desc-text mb-4"><?php echo $summary ?>...</p>
      <div class="d-flex justify-content-end">
          <a class="btn brutal-nav-btn brutal-btn-yellow font-weight-bold" href="<?php echo SWB.'index.php?p='.$path ?>">
              <?= __('Read More') ?> <i class="fas fa-arrow-right ml-1"></i>
          </a>
      </div>
  </div>

  <?php
}