/**
 * @Author: Waris Agung Widodo <user>
 * @Date:   2018-01-21T12:15:49+07:00
 * @Email:  ido.alit@gmail.com
 * @Filename: app.js
 * @Last modified by:   user
 * @Last modified time: 2018-01-23T18:22:24+07:00
 */

'use strict';

Vue.directive('click-outside', {
    priority: 700,
    bind: function (el, binding, vnode) {
        window.event = function (event) {
            if (!(el === event.target || el.contains(event.target))) {
                vnode.context[binding.expression](event);
            }
        };
        document.body.addEventListener('click', window.event)
    },
    unbind: function (el) {
        document.body.removeEventListener('click', window.event)
    },
});

const show_advanced = new Vue({
    el: '#search-wraper',
    data: function () {
        return {
            show: false,
            isFocus: false,
            searchBy: 'keywords',
            keywords: '',
            tmpObj: {}
        }
    },
    computed: {
        lastKeywords: function () {
            let raw = localStorage.getItem('keywords')
            if (raw) {
                try {
                    let keywords = JSON.parse(raw), arr = []
                    for (let key in keywords) {
                        if (keywords.hasOwnProperty(key)) {
                            arr.push(keywords[key].time)
                            keywords[key].text = key
                            this.tmpObj[keywords[key].time] = keywords[key]
                        }
                    }
                    arr.sort()
                    arr.reverse()
                    return arr.slice(0, 5)
                } catch (e) {
                    console.error(e.message)
                    return []
                }
            }
            return []
        }
    },
    methods: {
        searchOnFocus: function (e) {
            this.show = true;
            this.isFocus = true;
            const urlParams = new URLSearchParams(window.location.search);
            const search = urlParams.get('search');
            const page = urlParams.get('p');
            if (!search && !page) window.scrollTo(0, 250)
        },
        searchOnBlur: function (e) {
            this.isFocus = false
        },
        hideSearch: function () {
            if (!this.isFocus) {
                this.show = false;
                this.searchBy = 'keywords'
            }
        },
        searchOnClick: function (searchBy) {
            this.searchBy = searchBy
            this.searchSubmit()
        },
        searchSubmit: function () {
            if (this.keywords !== '') this.saveKeyword()
            window.location.href = `index.php?${this.searchBy}=${this.keywords}&search=search`;
        },
        saveKeyword: function () {
            let rawKeywords = localStorage.getItem('keywords')
            let keywords = {};
            if (rawKeywords) {
                try {
                    keywords = JSON.parse(rawKeywords)
                } catch (e) {
                    console.error(e.message)
                }
            }
            if (keywords.hasOwnProperty(this.keywords)) {
                keywords[this.keywords] = {
                    count: keywords[this.keywords].count + 1,
                    searchBy: this.searchBy,
                    time: Date.now()
                }
            } else {
                keywords[this.keywords] = {
                    count: 1,
                    searchBy: this.searchBy,
                    time: Date.now()
                }
            }
            let strKeyword = JSON.stringify(keywords)
            localStorage.setItem('keywords', strKeyword)
        }
    }
});

Vue.component('slims-subject', {
    props: {
        topic: {
            type: String,
            default: ''
        }
    },
    render: function(createElement) {
        return createElement('a', {
            domProps: {
                innerHTML: `#${this.topic}`
            },
            attrs: {
                href: `index.php?subject="${encodeURIComponent(this.topic).replace(/%20/g, "+")}"&search=search`,
                class: 'brutal-subject-pill mr-2 mb-2 d-inline-block'
            }
        })
    }
});

Vue.component('slims-book', {
    props: {
        biblioId: {
            type: String,
            default: ''
        },
        title: {
            type: String,
            default: ''
        },
        image: {
            type: String,
            default: ''
        }
    },
    render: function (createElement) {
        return createElement('div', {
            attrs: {
                class: 'brutal-book-col col-6 col-sm-4 col-md-3 col-lg-2 mb-4 d-flex align-items-stretch'
            }
        }, [
            createElement('a', {
                attrs: {
                    href: `index.php?p=show_detail&id=${this.biblioId}`,
                    class: 'brutal-book-card w-100 d-flex flex-column justify-content-between text-decoration-none'
                },
            }, [
                createElement('div', {
                    attrs: {
                        class: 'brutal-book-top'
                    }
                }, [
                    createElement('div', {
                        attrs: {
                            class: 'brutal-book-tagbar d-flex justify-content-between align-items-center'
                        }
                    }, [
                        createElement('span', {
                            attrs: { class: 'brutal-book-id' },
                            domProps: { innerHTML: `ID #${this.biblioId}` }
                        }),
                        createElement('span', {
                            attrs: { class: 'brutal-book-badge' },
                            domProps: { innerHTML: 'BOOK' }
                        })
                    ]),
                    createElement('div', {
                        attrs: {
                            class: 'brutal-book-cover-frame'
                        }
                    }, [
                        createElement('img', {
                            attrs: {
                                src: this.image,
                                class: 'brutal-book-img',
                                loading: 'lazy',
                                alt: this.title
                            }
                        }),
                        createElement('span', {
                            attrs: { class: 'brutal-book-corner-badge' },
                            domProps: { innerHTML: '★ NEW' }
                        })
                    ]),
                    createElement('div', {
                        attrs: {
                            class: 'brutal-book-title-box p-2'
                        }
                    }, [
                        createElement('h5', {
                            attrs: {
                                class: 'brutal-book-title',
                                title: this.title
                            },
                            domProps: {
                                innerHTML: this.title
                            }
                        })
                    ])
                ]),
                createElement('div', {
                    attrs: {
                        class: 'brutal-book-footer p-2'
                    }
                }, [
                    createElement('div', {
                        attrs: { class: 'brutal-book-action d-flex justify-content-between align-items-center' }
                    }, [
                        createElement('span', {
                            attrs: { class: 'brutal-book-btn-label' },
                            domProps: { innerHTML: 'DETAIL' }
                        }),
                        createElement('span', {
                            attrs: { class: 'brutal-book-btn-arrow' },
                            domProps: { innerHTML: '➔' }
                        })
                    ])
                ])
            ])
        ])
    }
});

Vue.component('slims-member', {
    props: {
        image: {
            type: String,
            default: ''
        },
        memberName: {
            type: String,
            default: ''
        },
        memberType: {
            type: String,
            default: ''
        },
        totalLoan: {
            type: String,
            default: '0'
        },
        totalBiblio: {
            type: String,
            default: '0'
        }
    },
    render: function (createElement) {
        return createElement('div', {
            attrs: {
                class: 'col-12 col-md-4 mb-4 d-flex align-items-stretch'
            }
        }, [
            createElement('div', {
                attrs: {
                    class: 'brutal-member-card w-100 d-flex flex-column justify-content-between'
                }
            }, [
                createElement('div', {
                    attrs: {
                        class: 'brutal-member-card-top'
                    }
                }, [
                    createElement('div', {
                        attrs: {
                            class: 'brutal-member-card-header d-flex justify-content-between align-items-center'
                        }
                    }, [
                        createElement('span', {
                            attrs: { class: 'brutal-member-badge' },
                            domProps: { innerHTML: '[ MEMBER ]' }
                        }),
                        createElement('span', {
                            attrs: { class: 'brutal-member-type' },
                            domProps: { innerHTML: this.memberType }
                        })
                    ]),
                    createElement('div', {
                        attrs: {
                            class: 'brutal-member-body p-3 text-center'
                        }
                    }, [
                        createElement('div', {
                            attrs: {
                                class: 'brutal-member-avatar-box mx-auto mb-2'
                            }
                        }, [
                            createElement('img', {
                                attrs: {
                                    class: 'brutal-member-avatar',
                                    src: this.image,
                                    loading: 'lazy',
                                    alt: this.memberName
                                }
                            })
                        ]),
                        createElement('h5', {
                            attrs: {
                                class: 'brutal-member-name mb-3'
                            },
                            domProps: {
                                innerHTML: this.memberName
                            }
                        })
                    ])
                ]),
                createElement('div', {
                    attrs: {
                        class: 'brutal-member-stats-grid d-flex justify-content-around p-2'
                    }
                }, [
                    createElement('div', {
                        attrs: { class: 'brutal-stat-col text-center' }
                    }, [
                        createElement('strong', {
                            attrs: { class: 'brutal-stat-val d-block' },
                            domProps: { innerHTML: this.totalLoan }
                        }),
                        createElement('span', {
                            attrs: { class: 'brutal-stat-tag' },
                            domProps: { innerHTML: 'TOTAL LOAN' }
                        })
                    ]),
                    createElement('div', {
                        attrs: { class: 'brutal-stat-divider' }
                    }),
                    createElement('div', {
                        attrs: { class: 'brutal-stat-col text-center' }
                    }, [
                        createElement('strong', {
                            attrs: { class: 'brutal-stat-val d-block' },
                            domProps: { innerHTML: this.totalBiblio }
                        }),
                        createElement('span', {
                            attrs: { class: 'brutal-stat-tag' },
                            domProps: { innerHTML: 'TITLES READ' }
                        })
                    ])
                ])
            ])
        ])
    }
});

Vue.component('slims-collection', {
    props: {
        url: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            biblios: [],
            loading: false
        }
    },
    mounted() {
        this.getData()
    },
    methods: {
        getData() {
            this.loading = true
            fetch(this.url)
                .then(res => res.json())
                .then(res => {
                    if (Array.isArray(res)) {
                        this.biblios = res
                    } else {
                        this.biblios = []
                    }
                })
                .catch(() => {
                    this.biblios = []
                })
                .finally(() => {
                    this.loading = false
                })
        }
    },
    render: function (createElement) {
        if (this.loading && this.biblios.length < 1) {
            return createElement('div', {
                attrs: {
                    class: 'brutal-loading-box d-flex align-items-center p-3 my-3'
                }
            }, [
                createElement('div', {
                    attrs: {
                        class: 'spinner-border text-dark mr-3',
                        role: 'status'
                    }
                }),
                createElement('span', {
                    attrs: { class: 'brutal-loading-code font-weight-bold' },
                    domProps: {
                        innerHTML: '>_ FETCHING_CATALOGUE_DATA...'
                    }
                })
            ])
        } else if (!this.loading && this.biblios.length < 1) {
            return createElement('div', {
                attrs: {
                    class: 'brutal-empty-box p-3 my-3'
                }
            }, [
                createElement('span', {
                    attrs: { class: 'brutal-empty-stamp' },
                    domProps: {
                        innerHTML: '[!] BELUM ADA KOLEKSI TERSEDIA SAAT INI'
                    }
                })
            ])
        } else {
            return createElement('div', {
                attrs: {
                    class: 'row brutal-book-collection mt-3'
                }
            }, this.biblios.map(function (item) {
                return createElement('slims-book', {
                    attrs: {
                        biblioId: item.biblio_id,
                        image: item.image,
                        title: item.title,
                    }
                })
            }))
        }
    }
});

Vue.component('slims-group-subject', {
    props: {
        url: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            subjects: [],
            loading: false
        }
    },
    mounted() {
        this.getData()
    },
    methods: {
        getData() {
            this.loading = true
            fetch(this.url)
                .then(res => res.json())
                .then(res => {
                    if (Array.isArray(res)) {
                        this.subjects = res
                    } else {
                        this.subjects = []
                    }
                })
                .catch(() => {
                    this.subjects = []
                })
                .finally(() => {
                    this.loading = false
                })
        }
    },
    render: function (createElement) {
        if (this.loading && this.subjects.length < 1) {
            return createElement('div', {
                attrs: {
                    class: 'p-2'
                }
            }, [
                createElement('span', {
                    attrs: { class: 'brutal-loading-code text-muted' },
                    domProps: {
                        innerHTML: '>_ LOADING_TOPICS...'
                    }
                })
            ])
        } else {
            return createElement('div', {
                attrs: {
                    class: 'd-flex flex-wrap brutal-subject-wrapper mb-3'
                }
            }, this.subjects.map(function (topic) {
                return createElement('slims-subject', {
                    attrs: {
                        topic
                    }
                })
            }))
        }
    }
});

Vue.component('slims-group-member', {
    props: {
        url: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            members: [],
            loading: false
        }
    },
    mounted() {
        this.getData()
    },
    methods: {
        getData() {
            this.loading = true
            fetch(this.url)
                .then(res => res.json())
                .then(res => {
                    if (Array.isArray(res)) {
                        this.members = res
                    } else {
                        this.members = []
                    }
                })
                .catch(() => {
                    this.members = []
                })
                .finally(() => {
                    this.loading = false
                })
        }
    },
    render: function (createElement) {
        if (this.loading && this.members.length < 1) {
            return createElement('div', {
                attrs: {
                    class: 'brutal-loading-box d-flex align-items-center p-3 my-3'
                }
            }, [
                createElement('div', {
                    attrs: {
                        class: 'spinner-border text-dark mr-3',
                        role: 'status'
                    }
                }),
                createElement('span', {
                    attrs: { class: 'brutal-loading-code font-weight-bold' },
                    domProps: {
                        innerHTML: '>_ LOADING_TOP_READERS...'
                    }
                })
            ])
        } else if (!this.loading && this.members.length < 1) {
            return createElement('div', {
                attrs: {
                    class: 'brutal-empty-box p-3 my-3'
                }
            }, [
                createElement('span', {
                    attrs: { class: 'brutal-empty-stamp' },
                    domProps: {
                        innerHTML: '[!] BELUM ADA DATA PEMBACA TERATAS'
                    }
                })
            ])
        } else {
            return createElement('div', {
                attrs: {
                    class: 'row brutal-member-collection mt-3'
                }
            }, this.members.map(function (member) {
                return createElement('slims-member', {
                    attrs: {
                        memberName: member.name,
                        memberType: member.type,
                        image: member.image,
                        totalLoan: member.total,
                        totalBiblio: member.total_title
                    }
                })
            }))
        }
    }
});

if (document.getElementById('slims-home')) {
    const slimsHome = new Vue({
        el: '#slims-home',
    })
}