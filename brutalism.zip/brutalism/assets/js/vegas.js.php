<?php
/**
 * @Created by          : Waris Agung Widodo (ido.alit@gmail.com)
 * @Date                : 2019-01-29 23:33
 * @File name           : vegas.js.php
 * @Modified for        : Neo-Brutalism Theme (Slide disabled in favor of clean Brutalist Canvas)
 */
// Slideshow disabled for Neo-Brutalism theme