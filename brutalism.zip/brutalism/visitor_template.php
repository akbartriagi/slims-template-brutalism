<?php
/**
 * @Created by          : Waris Agung Widodo (ido.alit@gmail.com)
 * @Date                : 2020-01-03 08:49
 * @File name           : visitor_template.php
 * @Modified for        : Neo-Brutalism Theme
 */

$main_template_path = __DIR__ . '/login_template.inc.php';

// set default language
if (isset($_GET['select_lang'])) {
    $select_lang = trim(strip_tags($_GET['select_lang']));
    // delete previous language cookie
    if (isset($_COOKIE['select_lang'])) {
        @setcookie('select_lang', $select_lang, [
            'expires' => time()-14400,
            'path' => SWB,
            'domain' => '',
            'secure' => false,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
    // create language cookie
    @setcookie('select_lang', $select_lang, [
        'expires' => time()+14400,
        'path' => SWB,
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    $sysconf['default_lang'] = $select_lang;
} else if (isset($_COOKIE['select_lang'])) {
    $sysconf['default_lang'] = trim(strip_tags($_COOKIE['select_lang']));
}

?>

<div id="visitor-counter">
    <!-- Top Utility Bar -->
    <div class="brutal-visitor-topbar py-3 px-4 border-bottom-black d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <a href="index.php" class="btn brutal-btn-black mr-3" title="Kembali ke OPAC">
                <i class="fas fa-arrow-left mr-1"></i> <span class="d-none d-sm-inline">KATALOG OPAC</span>
            </a>
            <div class="brutal-brand-badge font-weight-bold">
                <i class="fas fa-university mr-1"></i> <?= $sysconf['library_name']; ?>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <div class="brutal-live-clock font-weight-bold">
                <i class="far fa-clock mr-1"></i> {{ currentTime }}
            </div>
        </div>
    </div>

    <!-- Main Kiosk Body -->
    <div class="brutal-visitor-wrapper py-4 py-lg-5">
        <div class="container-fluid px-3 px-lg-5">
            <div class="row align-items-stretch">
                
                <!-- Left: Check-in Form Card -->
                <div class="col-lg-5 col-xl-4 mb-4 mb-lg-0 d-flex flex-column">
                    <div class="brutal-card brutal-visitor-form-card flex-grow-1 p-4 p-md-5 d-flex flex-column justify-content-between">
                        <div>
                            <!-- Header Bar -->
                            
                            <h2 class="brutal-visitor-title mb-2"><?= __('Welcome to ').$sysconf['library_name']; ?></h2>
                            <p class="brutal-visitor-subtitle mb-4">
                                <?= __('Please fill your member ID or name.')?>
                            </p>

                            <!-- Mobile Feedback Notice -->
                            <div v-if="textInfo !== ''" class="brutal-alert-box brutal-alert-yellow p-3 mb-4 d-md-none" v-html="textInfo"></div>

                            <!-- Form -->
                            <form @submit.prevent="onSubmit">
                                <div class="form-group mb-3">
                                    <label for="memberId" class="brutal-form-label d-flex justify-content-between">
                                        <span><?= __('Member ID')?></span>
                                        <span class="brutal-field-hint">[ SCAN / KETIK ]</span>
                                    </label>
                                    <div class="brutal-input-group">
                                        <span class="brutal-input-icon"><i class="fas fa-id-card"></i></span>
                                        <input v-model="memberId" ref="memberId" autofocus type="text" 
                                               class="form-control brutal-visitor-input" id="memberId"
                                               autocomplete="off"
                                               placeholder="<?= __('Enter your member ID')?>">
                                    </div>
                                </div>

                                <div class="form-group mb-4">
                                    <label for="institution" class="brutal-form-label d-flex justify-content-between">
                                        <span><?= __('Institution')?></span>
                                        <span class="brutal-field-hint text-muted">[ OPSIONAL ]</span>
                                    </label>
                                    <div class="brutal-input-group">
                                        <span class="brutal-input-icon"><i class="fas fa-building"></i></span>
                                        <input v-model="institution" type="text" 
                                               class="form-control brutal-visitor-input" id="institution"
                                               autocomplete="off"
                                               placeholder="<?= __('Enter your institution')?>">
                                    </div>
                                    <div class="brutal-input-help mt-2">
                                        <i class="fas fa-info-circle mr-1"></i> <?= __('Enough fill your member ID if you are member of ').$sysconf['library_name']; ?>
                                    </div>
                                </div>

                                <button type="submit" class="btn brutal-btn-yellow btn-block brutal-checkin-btn">
                                    <span><?= __('Check In')?></span> <i class="fas fa-arrow-right ml-2"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Right: Interactive Display Billboard -->
                <div class="col-lg-7 col-xl-8 d-flex flex-column">
                    
                    <!-- State 1: Active Welcome / Check-In Success -->
                    <div v-show="textInfo !== ''" class="brutal-card brutal-welcome-card flex-grow-1 p-4 p-md-5 d-flex flex-column justify-content-between mb-4">
                        <div>

                            <div class="row align-items-center my-4">
                                <div class="col-md-auto text-center mb-4 mb-md-0">
                                    <div class="brutal-visitor-photo-box mx-auto">
                                        <img :src="image" alt="Visitor Photo" class="brutal-visitor-photo" @error="onImageError">
                                    </div>
                                </div>
                                <div class="col-md pl-md-4">
                                    <div class="brutal-speech-bubble p-4">
                                        <span class="brutal-greeting-tag mb-2">[ SELAMAT DATANG ]</span>
                                        <h3 class="brutal-welcome-msg mt-2 mb-0" v-html="textInfo"></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="brutal-welcome-footer p-3 bg-white border-black d-flex justify-content-between align-items-center">
                            <span class="font-weight-bold"><i class="fas fa-check-circle text-success mr-1"></i> Data kunjungan Anda telah berhasil dicatat ke dalam log sistem.</span>
                            <span class="brutal-tag-mono d-none d-sm-inline">[ TERIMA KASIH ]</span>
                        </div>
                    </div>

                    <!-- State 2: Idle Quote & Library Info Billboard -->
                    <div v-show="textInfo === ''" class="brutal-card brutal-billboard-card flex-grow-1 p-4 p-md-5 d-flex flex-column justify-content-between mb-4">
                        <div>
                            <!-- Header Tags -->
                            <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
                                <div>
                                    <span class="brutal-sticker brutal-sticker-yellow mr-2">QUOTES OF THE DAY</span>
                                    <span class="brutal-sticker brutal-sticker-pink d-none d-sm-inline-block">INSPIRATION</span>
                                </div>
                                <span class="brutal-code-stamp">[ MOTIVASI BACA ]</span>
                            </div>

                            <!-- Big Quote Display -->
                            <div class="brutal-quote-wrapper my-4 p-4 p-lg-5">
                                <div class="brutal-quote-symbol">“</div>
                                <p class="brutal-quote-text mb-3">{{quotes.content}}</p>
                                <div class="brutal-quote-author">
                                    <span class="author-dash">—</span> <span class="author-name">{{quotes.author}}</span>
                                </div>
                            </div>
                        </div>

                        <!-- 3 Feature Badges on Bottom of Billboard -->
                        <div class="row brutal-feature-tiles mt-3">
                            <div class="col-md-4 mb-2 mb-md-0">
                                <div class="brutal-mini-tile tile-cyan p-3">
                                    <div class="tile-label"><i class="fas fa-book-reader mr-1"></i> RUANG BACA</div>
                                    <div class="tile-desc">Kenyamanan membaca & fasilitas belajar mandiri</div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-2 mb-md-0">
                                <div class="brutal-mini-tile tile-yellow p-3">
                                    <div class="tile-label"><i class="fas fa-wifi mr-1"></i> FREE WI-FI</div>
                                    <div class="tile-desc">Akses internet cepat untuk riset literatur</div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="brutal-mini-tile tile-lime p-3">
                                    <div class="tile-label"><i class="fas fa-search mr-1"></i> OPAC ONLINE</div>
                                    <div class="tile-desc">Pencarian ribuan judul buku & karya ilmiah</div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo $sysconf['template']['dir'].'/'.$sysconf['template']['theme'].'/assets/js/axios.min.js'; ?>"></script>
<script src="<?= JWB . 'he.js' ?>"></script>
<script>
    new Vue({
        el: '#visitor-counter',
        data() {
            return {
                memberId: '',
                institution: '',
                textInfo: '',
                image: './images/persons/photo.png',
                quotes: {},
                timeout: null,
                currentTime: '',
                csrfName: '<?= \Volnix\CSRF\CSRF::getTokenName() ?>',
                csrfToken: '<?= \Volnix\CSRF\CSRF::getToken() ?>'
            }
        },
        mounted() {
            this.$refs.memberId.focus()
            this.getQuotes()
            this.updateClock()
            setInterval(this.updateClock, 1000)
        },
        methods: {
            updateClock: function() {
                const now = new Date()
                const hours = String(now.getHours()).padStart(2, '0')
                const minutes = String(now.getMinutes()).padStart(2, '0')
                const seconds = String(now.getSeconds()).padStart(2, '0')
                this.currentTime = `${hours}:${minutes}:${seconds}`
            },
            onImageError: function() {
                this.image = './images/persons/photo.png'
            },
            getQuotes: function() {
                axios.get('https://slims.web.id/kutipan/')
                    .then(res => {
                        res.data.content = he.decode(res.data.content)
                        this.quotes = res.data
                    })
                    .catch(() => {
                        this.quotes = {
                            content: "Buku adalah jembatan ilmu yang menghubungkan masa lalu dengan masa depan.",
                            author: "Perpustakaan"
                        }
                    })
                    .finally(() => {
                        this.textInfo = ''
                    })
            },
            onSubmit: function() {
                if (this.memberId === '') {
                    this.resetForm()
                    return
                }
                let url = 'index.php?p=visitor<?= trim(isset($_GET['room']) ? '&room=' . simbio_security::xssFree($_GET['room']) : '')  ?>'
                let data = new FormData()
                data.append('memberID', this.memberId)
                data.append('institution', this.institution)
                data.append('counter', 1)
                data.append(this.csrfName, this.csrfToken)

                axios({
                    url: url,
                    method: 'post',
                    data: data,
                    headers: {'Content-Type': 'multipart/form-data', 'X-Response-With': 'application/json' }
                })
                    .then(res => {
                        this.textInfo = res.data.message
                        this.image = `./images/persons/${res.data.image}`
                        if (res.data.new_token) {
                            this.csrfToken = res.data.new_token
                        }
                        <?php if ($sysconf['template']['visitor_log_voice']) : ?>
                            this.textToSpeech(this.textInfo.replace(/(<([^>]+)>)/ig, ''))
                        <?php endif; ?>
                    })
                    .catch(err => {
                        console.log(err);
                        if (err.response && err.response.data.new_token) {
                            this.csrfToken = err.response.data.new_token
                        }
                    })
                    .finally(() => {
                        this.resetForm()
                        clearTimeout(this.timeout)
                        this.timeout = setTimeout(() => {
                            this.getQuotes()
                        }, 5000)
                    })
            },
            resetForm: function () {
                this.memberId = ''
                this.institution = ''
                this.$refs.memberId.focus()
            },
            textToSpeech: function(message) {
                var message = new SpeechSynthesisUtterance(message);
                var voices = speechSynthesis.getVoices();
                message['volume'] = 1;
                message['rate'] = 1;
                message['pitch'] = 1;
                message['lang'] = '<?php echo str_replace('_', '-', $sysconf['default_lang']); ?>';
                message['voice'] = null;
                speechSynthesis.cancel();
                speechSynthesis.speak(message);
            }
        }
    })
</script>
