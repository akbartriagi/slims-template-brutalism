<?php
/**
 * @Created by          : Waris Agung Widodo (ido.alit@gmail.com)
 * @Date                : 2019-01-30 20:58
 * @File name           : _member.php
 * @Modified for        : Neo-Brutalism Theme
 */
?>

<?php if ($is_login) : ?>

    <div class="member-area brutal-member-dashboard-page">
        <section id="section1 container-fluid">
            <header class="c-header brutal-header">
              <?php include '_navbar.php'; ?>
            </header>
        </section>

        <div class="container my-5">
            <div class="brutal-section-box p-4 p-md-5">
                <div class="brutal-section-header mb-4 pb-2 border-bottom-black d-flex flex-wrap justify-content-between align-items-center">
                    <div>
                        <span class="brutal-badge-pill brutal-pill-lime mb-2 d-inline-block">● ACTIVE SESSION</span>
                        <h2 class="brutal-heading-h3 m-0"><?= __('Member Area'); ?></h2>
                    </div>
                    <span class="brutal-code-stamp d-none d-md-inline-block">[ DASHBOARD_MEMBER.SYS ]</span>
                </div>
                
                <div class="brutal-member-content-wrap">
                    <?php echo $main_content; ?>
                </div>
            </div>
        </div>

    </div>

<?php else: ?>

    <div class="page-member-area brutal-member-login-page">
        <section id="section1 container-fluid">
            <header class="c-header brutal-header">
              <?php include '_navbar.php'; ?>
            </header>
        </section>

        <div class="container my-5">
            <div class="row">
                <div class="col-lg-6 col-md-8 mx-auto">
                    <div class="brutal-member-login-card">

                        <!-- Card Body -->
                        <div class="p-4 p-md-5 bg-white">
                            <div class="brutal-login-title-box mb-4">
                                <h2 class="brutal-heading-h2 m-0"><?= __('Member Login'); ?></h2>
                            </div>
                            
                            <div class="brutal-member-form-wrap">
                                <?php echo $main_content; ?>
                            </div>

                            <div class="brutal-login-help-box mt-4 p-3 border-black">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-question-circle fa-2x text-dark mr-3"></i>
                                    <div class="text-sm">
                                        <strong>Belum memiliki akun anggota?</strong>
                                        <div class="text-muted">Silakan hubungi bagian sirkulasi atau staf perpustakaan untuk pendaftaran kartu anggota baru.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php endif; ?>
