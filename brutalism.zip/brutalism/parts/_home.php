<?php
# @Author: Waris Agung Widodo <user>
# @Date:   2018-01-23T11:27:04+07:00
# @Email:  ido.alit@gmail.com
# @Filename: _home.php
# @Last modified time: 2026-10-18T20:32:00+07:00
?>

<!-- ==========================================================================
     HERO & SEARCH SECTION
     ========================================================================== -->
<section id="section1 container-fluid">
    <header class="c-header brutal-header">
        <?php
        // ------------------------------------------------------------------------
        // include navbar
        // ------------------------------------------------------------------------
        include '_navbar.php'; ?>

        <!-- Brutalist Infinite Marquee Banner -->
        <?php
        if (($sysconf['template']['brutal_marquee_enable'] ?? 1) == 1) :
            global $dbs, $sysconf;
            $marquee_source = $sysconf['template']['brutal_marquee_source'] ?? 'biblio_new';
            $marquee_count = (int)($sysconf['template']['brutal_marquee_item_count'] ?? 10);
            if ($marquee_count <= 0) $marquee_count = 10;
            $base_url = defined('SWB') ? SWB : '';

            $marquee_items = [];

            if ($marquee_source === 'biblio_new') {
                if (function_exists('getLatestBiblio')) {
                    $raw_books = getLatestBiblio($dbs, $marquee_count);
                } else {
                    $raw_books = [];
                    $q = $dbs->query("SELECT biblio_id, title FROM biblio ORDER BY input_date DESC, last_update DESC LIMIT {$marquee_count}");
                    if ($q) {
                        while ($row = $q->fetch_assoc()) { $raw_books[] = $row; }
                    }
                }
                foreach ($raw_books as $book) {
                    $marquee_items[] = [
                        'tag' => __('BUKU BARU'),
                        'title' => $book['title'],
                        'url' => $base_url . 'index.php?p=show_detail&id=' . (int)$book['biblio_id']
                    ];
                }
            } elseif ($marquee_source === 'biblio_popular') {
                if (function_exists('getPopularBiblio')) {
                    $raw_books = getPopularBiblio($dbs, $marquee_count);
                } else {
                    $raw_books = [];
                }
                foreach ($raw_books as $book) {
                    $marquee_items[] = [
                        'tag' => __('POPULER'),
                        'title' => $book['title'],
                        'url' => $base_url . 'index.php?p=show_detail&id=' . (int)$book['biblio_id']
                    ];
                }
            } elseif ($marquee_source === 'news') {
                $news_q = $dbs->query("SELECT content_id, content_title, content_path FROM content WHERE is_news = 1 AND is_draft = 0 ORDER BY publish_date DESC, last_update DESC LIMIT {$marquee_count}");
                if (!$news_q || $news_q->num_rows === 0) {
                    // Fallback to active content pages if no news records flagged
                    $news_q = $dbs->query("SELECT content_id, content_title, content_path FROM content WHERE is_draft = 0 AND content_path NOT IN ('adminhome', 'headerinfo') ORDER BY last_update DESC LIMIT {$marquee_count}");
                }
                if ($news_q && $news_q->num_rows > 0) {
                    while ($news_row = $news_q->fetch_assoc()) {
                        $url = !empty($news_row['content_path']) ? ($base_url . 'index.php?p=' . urlencode($news_row['content_path'])) : ($base_url . 'index.php?p=news');
                        $marquee_items[] = [
                            'tag' => __('BERITA'),
                            'title' => $news_row['content_title'],
                            'url' => $url
                        ];
                    }
                }
            } elseif ($marquee_source === 'custom') {
                $custom_raw = $sysconf['template']['brutal_marquee_custom_text'] ?? '';
                $parts = explode('|', $custom_raw);
                foreach ($parts as $part) {
                    $clean = trim(strip_tags($part));
                    if (!empty($clean)) {
                        $marquee_items[] = [
                            'tag' => 'INFO',
                            'title' => $clean,
                            'url' => ''
                        ];
                    }
                }
            }

            // Fallback preset if empty or source is slogan
            if (empty($marquee_items)) {
                $marquee_items = [
                    ['tag' => '★', 'title' => 'SENAYAN LIBRARY MANAGEMENT SYSTEM', 'url' => ''],
                    ['tag' => '✦', 'title' => 'OPEN ACCESS CATALOG', 'url' => ''],
                    ['tag' => '■', 'title' => 'BROWSE BOOKS, PAPERS & JOURNALS', 'url' => ''],
                    ['tag' => '▲', 'title' => 'KNOWLEDGE IS NOT A PRIVILEGE', 'url' => ''],
                    ['tag' => '●', 'title' => 'NO COMPROMISE DESIGN', 'url' => ''],
                    ['tag' => '★', 'title' => 'READ MORE EVERY DAY', 'url' => ''],
                ];
            }
        ?>
        <div class="brutal-marquee-container" title="<?= __('Arahkan kursor untuk jeda / klik untuk membuka detail') ?>">
            <div class="brutal-marquee-track">
                <?php for ($loop = 0; $loop < 2; $loop++) : ?>
                    <?php foreach ($marquee_items as $item) : ?>
                        <span class="brutal-marquee-item">
                            <span class="brutal-marquee-tag"><?= htmlspecialchars($item['tag']) ?></span>
                            <?php if (!empty($item['url'])) : ?>
                                <a href="<?= $item['url'] ?>" class="brutal-marquee-link"><?= htmlspecialchars($item['title']) ?></a>
                            <?php else : ?>
                                <span class="brutal-marquee-text"><?= htmlspecialchars($item['title']) ?></span>
                            <?php endif; ?>
                            <span class="brutal-marquee-sep">✦</span>
                        </span>
                    <?php endforeach; ?>
                <?php endfor; ?>
            </div>
        </div>
        <?php endif; ?>


        <!-- Brutalist Hero Billboard -->
        <?php if (($sysconf['template']['brutal_hero_enable'] ?? 1) == 1) : 
            $hero_badges_str = $sysconf['template']['brutal_hero_badges'] ?? '★ OPEN SOURCE OPAC | ✦ DIGITAL ARCHIVE | ● RAW KNOWLEDGE';
            $hero_badges = array_filter(array_map('trim', explode('|', $hero_badges_str)));
            $badge_colors = ['brutal-sticker-yellow', 'brutal-sticker-pink', 'brutal-sticker-cyan'];
            
            $hero_title = $sysconf['template']['brutal_hero_title'] ?? 'SEARCH. DISCOVER.';
            $hero_highlight = $sysconf['template']['brutal_hero_highlight'] ?? 'CONQUER.';
            $hero_sub = $sysconf['template']['brutal_hero_sub'] ?? 'Pusat khazanah pustaka, naskah riset, dan koleksi ilmu pengetahuan tanpa sekat. Temukan ribuan referensi dalam genggaman.';
        ?>
        <div class="container brutal-hero-container text-center py-4 py-md-5">
            <?php if (!empty($hero_badges)) : ?>
            <div class="d-inline-flex flex-wrap justify-content-center align-items-center mb-3">
                <?php foreach (array_values($hero_badges) as $idx => $badge) : 
                    $color_class = $badge_colors[$idx % count($badge_colors)];
                ?>
                    <span class="brutal-sticker <?= $color_class ?> mr-2 mb-2"><?= htmlspecialchars($badge) ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <h1 class="brutal-hero-title mb-3">
                <?= htmlspecialchars($hero_title) ?>
                <?php if (!empty($hero_highlight)) : ?>
                    <span class="brutal-highlight-underline"><?= htmlspecialchars($hero_highlight) ?></span>
                <?php endif; ?>
            </h1>

            <?php if (!empty($hero_sub)) : ?>
            <p class="brutal-hero-sub mx-auto mb-1">
                <?= htmlspecialchars($hero_sub) ?>
            </p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </header>

    <?php
    // --------------------------------------------------------------------------
    // include search form part
    // --------------------------------------------------------------------------
    include '_search-form.php'; ?>
</section>

<div id="slims-home" class="brutal-main-content">



<!-- ==========================================================================
     TOPIC CATEGORIES IN BRUTALIST CARDS
     ========================================================================== -->
<section class="container my-5">
    <div class="brutal-section-header mb-4">
        <div class="d-flex align-items-center flex-wrap">
            <h3 class="brutal-heading-h3 mb-2"><?php echo __('Select the topic you are interested in'); ?></h3>
        </div>
        <p class="brutal-desc-text">Pilih subjek disiplin ilmu sesuai kebutuhan studi, penelitian, atau eksplorasi pribadi.</p>
    </div>

    <div class="row brutal-topic-grid">
        <!-- 1. Literature -->
        <div class="col-6 col-md-4 col-lg brutal-topic-col mb-4">
            <a href="index.php?callnumber=8&search=search" class="brutal-topic-card brutal-card-pink d-flex flex-column justify-content-between">
                <div class="brutal-topic-top d-flex justify-content-between align-items-center">
                    <span class="brutal-topic-code">800</span>
                    <span class="brutal-topic-badge">LIT</span>
                </div>
                <div class="brutal-topic-icon text-center my-3">
                    <img src="<?php echo assets('images/8-books.png'); ?>" width="68" class="mx-auto" alt="Literature"/>
                </div>
                <div class="brutal-topic-footer text-center">
                    <span class="brutal-topic-name"><?php echo __('Literature'); ?></span>
                    <span class="brutal-topic-arrow">→</span>
                </div>
            </a>
        </div>

        <!-- 2. Social Sciences -->
        <div class="col-6 col-md-4 col-lg brutal-topic-col mb-4">
            <a href="index.php?callnumber=3&search=search" class="brutal-topic-card brutal-card-cyan d-flex flex-column justify-content-between">
                <div class="brutal-topic-top d-flex justify-content-between align-items-center">
                    <span class="brutal-topic-code">300</span>
                    <span class="brutal-topic-badge">SOC</span>
                </div>
                <div class="brutal-topic-icon text-center my-3">
                    <img src="<?php echo assets('images/3-diploma.png'); ?>" width="68" class="mx-auto" alt="Social Sciences"/>
                </div>
                <div class="brutal-topic-footer text-center">
                    <span class="brutal-topic-name"><?php echo __('Social Sciences'); ?></span>
                    <span class="brutal-topic-arrow">→</span>
                </div>
            </a>
        </div>

        <!-- 3. Applied Sciences -->
        <div class="col-6 col-md-4 col-lg brutal-topic-col mb-4">
            <a href="index.php?callnumber=6&search=search" class="brutal-topic-card brutal-card-lime d-flex flex-column justify-content-between">
                <div class="brutal-topic-top d-flex justify-content-between align-items-center">
                    <span class="brutal-topic-code">600</span>
                    <span class="brutal-topic-badge">APP</span>
                </div>
                <div class="brutal-topic-icon text-center my-3">
                    <img src="<?php echo assets('images/6-blackboard.png'); ?>" width="68" class="mx-auto" alt="Applied Sciences"/>
                </div>
                <div class="brutal-topic-footer text-center">
                    <span class="brutal-topic-name"><?php echo __('Applied Sciences'); ?></span>
                    <span class="brutal-topic-arrow">→</span>
                </div>
            </a>
        </div>

        <!-- 4. Art & Recreation -->
        <div class="col-6 col-md-4 col-lg brutal-topic-col mb-4">
            <a href="index.php?callnumber=7&search=search" class="brutal-topic-card brutal-card-yellow d-flex flex-column justify-content-between">
                <div class="brutal-topic-top d-flex justify-content-between align-items-center">
                    <span class="brutal-topic-code">700</span>
                    <span class="brutal-topic-badge">ART</span>
                </div>
                <div class="brutal-topic-icon text-center my-3">
                    <img src="<?php echo assets('images/7-quill.png'); ?>" width="68" class="mx-auto" alt="Art & Recreation"/>
                </div>
                <div class="brutal-topic-footer text-center">
                    <span class="brutal-topic-name"><?php echo __('Art & Recreation'); ?></span>
                    <span class="brutal-topic-arrow">→</span>
                </div>
            </a>
        </div>

        <!-- 5. See More Modal -->
        <div class="col-6 col-md-4 col-lg brutal-topic-col mb-4">
            <a href="javascript:void(0)" class="brutal-topic-card brutal-card-purple d-flex flex-column justify-content-between cursor-pointer" data-toggle="modal" data-target="#exampleModal">
                <div class="brutal-topic-top d-flex justify-content-between align-items-center">
                    <span class="brutal-topic-code">ALL</span>
                    <span class="brutal-topic-badge">MORE</span>
                </div>
                <div class="brutal-topic-icon text-center my-3">
                    <img src="<?php echo assets('images/icon/grid_icon.png'); ?>" width="68" class="mx-auto" alt="See More"/>
                </div>
                <div class="brutal-topic-footer text-center">
                    <span class="brutal-topic-name"><?php echo __('see more..'); ?></span>
                    <span class="brutal-topic-arrow">✦</span>
                </div>
            </a>
        </div>
    </div>
</section>

<!-- ==========================================================================
     POPULAR COLLECTIONS SECTION
     ========================================================================== -->
<?php if ($sysconf['template']['classic_popular_collection']) : ?>
<section class="container my-5">
    <div class="brutal-section-box">
        <div class="brutal-section-title-bar d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="brutal-heading-h3 d-inline-block m-0"><?php echo __('Popular among our collections'); ?></h3>
            </div>
        </div>
        <p class="brutal-desc-text mb-4">
            <?php echo __('Our library\'s line of collection that have been favoured by our users were shown here. Look for them. Borrow them. Hope you also like them');?>
        </p>

        <slims-group-subject url="index.php?p=api/subject/popular"></slims-group-subject>
        <slims-collection url="index.php?p=api/biblio/popular"></slims-collection>
    </div>
</section>
<?php endif; ?>

<!-- ==========================================================================
     NEW COLLECTIONS SECTION
     ========================================================================== -->
<?php if ($sysconf['template']['classic_new_collection']) : ?>
<section class="container my-5">
    <div class="brutal-section-box brutal-box-yellow">
        <div class="brutal-section-title-bar d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="brutal-heading-h3 d-inline-block m-0"><?php echo __('New collections + updated');?></h3>
            </div>
        </div>
        <p class="brutal-desc-text mb-4">
            <?php echo __('These are new collections list. Hope you like them. Maybe not all of them are new. But in term of time, we make sure that these are fresh from our processing oven');?>
        </p>

        <slims-group-subject url="index.php?p=api/subject/latest"></slims-group-subject>
        <slims-collection url="index.php?p=api/biblio/latest"></slims-collection>
    </div>
</section>
<?php endif; ?>

<!-- ==========================================================================
     TOP READER SECTION
     ========================================================================== -->
<?php if ($sysconf['template']['classic_top_reader']) : ?>
<section class="container my-5">
    <div class="brutal-section-box brutal-box-lime">
        <div class="brutal-section-title-bar d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="brutal-heading-h3 d-inline-block m-0"><?php echo __('Top reader of the year');?></h3>
            </div>
        </div>
        <p class="brutal-desc-text mb-4">
            <?php echo __('Our best users, readers, so far. Continue to read if you want your name being mentioned here');?>
        </p>
        <slims-group-member url="index.php?p=api/member/top"></slims-group-member>
    </div>
</section>
<?php endif; ?>

<!-- ==========================================================================
     LOCATION & SOCIAL MEDIA MAP SECTION
     ========================================================================== -->
<?php if ($sysconf['template']['classic_map']) : ?>
<section class="container my-5">
    <div class="brutal-map-container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <div class="brutal-iframe-wrapper">
                    <div class="brutal-iframe-header">
                        <span>● ● ● GPS LOCATION MAP</span>
                    </div>
                    <iframe class="embed-responsive brutal-map-iframe"
                            src="<?= $sysconf['template']['classic_map_link']; ?>"
                            height="380" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-lg-6 pl-lg-4">
                <div class="brutal-info-panel">
                    <h3 class="brutal-heading-h3 mt-1 mb-3"><?= $sysconf['library_name']; ?></h3>
                    <div class="brutal-address-box mb-4">
                        <?= $sysconf['template']['classic_map_desc']; ?>
                    </div>
                    <div class="brutal-social-links d-flex flex-wrap pt-1">
                        <a target="_blank" href="<?= $sysconf['template']['classic_fb_link'] ?>" class="btn brutal-social-btn brutal-btn-blue mr-2 mb-2" title="Facebook">
                            <i class="fab fa-facebook-f mr-1"></i> FACEBOOK
                        </a>
                        <a target="_blank" href="<?= $sysconf['template']['classic_twitter_link'] ?>" class="btn brutal-social-btn brutal-btn-cyan mr-2 mb-2" title="Twitter">
                            <i class="fab fa-twitter mr-1"></i> TWITTER
                        </a>
                        <a target="_blank" href="<?= $sysconf['template']['classic_youtube_link'] ?>" class="btn brutal-social-btn brutal-btn-red mr-2 mb-2" title="YouTube">
                            <i class="fab fa-youtube mr-1"></i> YOUTUBE
                        </a>
                        <a target="_blank" href="<?= $sysconf['template']['classic_instagram_link'] ?>" class="btn brutal-social-btn brutal-btn-pink mr-2 mb-2" title="Instagram">
                            <i class="fab fa-instagram mr-1"></i> INSTAGRAM
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

</div>