<?php
# @Author: Waris Agung Widodo <user>
# @Date:   2018-01-25T10:25:29+07:00
# @Email:  ido.alit@gmail.com
# @Filename: _navbar.php
# @Last modified time: 2026-10-18T20:30:00+07:00

$main_menus = [
  'home' => [
    'text' => __('Home'),
    'url' => 'index.php'
  ],
  'libinfo' => [
    'text' => __('Information'),
    'url' => 'index.php?p=libinfo'
  ],
  'news' => [
    'text' => __('News'),
    'url' => 'index.php?p=news'
  ],
  'help' => [
    'text' => __('Help'),
    'url' => 'index.php?p=help'
  ],
  'librarian' => [
    'text' => __('Librarian'),
    'url' => 'index.php?p=librarian'
  ]
];
?>
<nav class="navbar navbar-expand-lg brutal-navbar px-3 py-2">
    <div class="container-fluid">
        <a class="navbar-brand brutal-brand d-inline-flex align-items-center" href="index.php">
            <div class="brutal-logo-badge mr-2">
                <?php
                if(isset($sysconf['logo_image']) && $sysconf['logo_image'] != '' && $imagesDisk->isExists($path = 'default/'.$sysconf['logo_image'])){
                    echo '<img class="brutal-logo-img" src="'.SWB . 'lib/minigalnano/createthumb.php?filename=images/' . $path.'&width=150">';
                }
                elseif (file_exists(__DIR__ . '/../assets/images/logo.png')) {
                    echo '<img class="brutal-logo-img" src="'.assets('images/logo.png').'">';
                } else {
                ?>
                <span class="brutal-logo-icon">📖</span>
                <?php } ?>
            </div>
            <div class="d-inline-flex flex-column leading-tight">
                <span class="brutal-brand-title"><?php echo $sysconf['library_name']; ?></span>
                <?php if ($sysconf['template']['classic_library_subname']) : ?>
                <span class="brutal-brand-sub"><?php echo $sysconf['library_subname']; ?></span>
                <?php else: ?>
                <?php endif; ?>
            </div>
        </a>

        <button class="navbar-toggler brutal-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="font-weight-bold text-dark"><i class="fas fa-bars mr-1"></i> MENU</span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto align-items-lg-center">
              <?php
              foreach ($main_menus as $key => $main_menu) {
                $active = '';
                if (isset($_GET['p'])) {
                  if ($key === $_GET['p']) $active = 'active';
                } elseif ($key === 'home') {
                  $active = 'active';
                }
                $menu_str = <<<HTML
<li class="nav-item m-1">
    <a class="nav-link brutal-nav-btn {$active}" href="{$main_menu['url']}">{$main_menu['text']}</a>
</li>
HTML;
                echo $menu_str;
              }
              ?>
              <?php
              $menu_member_active = isset($_GET['p']) && $_GET['p'] === 'member' ? 'active' : '';
              if ($is_login) {
                ?>
                  <li class="nav-item m-1">
                      <a class="nav-link brutal-nav-btn brutal-btn-pink <?= $menu_member_active; ?>" href="index.php?p=member&sec=title_basket">
                          <i class="fas fa-shopping-basket mr-1"></i>
                        <?php
                        $count_basket = count($_SESSION['m_mark_biblio'] ?? []);
                        ?>
                          <span id="count-basket" class="brutal-badge-count"><?php echo $count_basket; ?></span>
                      </a>
                  </li>
                  <li class="nav-item dropdown m-1 <?= $menu_member_active; ?>">
                      <a class="nav-link dropdown-toggle brutal-nav-btn brutal-btn-cyan" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                         aria-haspopup="true" aria-expanded="false">
                          <img class="w-6 h-6 rounded-none brutal-avatar mr-1"
                               src="<?php echo $member_image_path; ?>"
                               alt="Avatar">
                        <?php echo htmlspecialchars($_SESSION['m_name'] ?? 'Member'); ?>
                      </a>
                      <div class="dropdown-menu dropdown-menu-right brutal-dropdown">
                          <a class="dropdown-item brutal-dropdown-item" href="index.php?p=member"><i class="fas fa-user-circle mr-2"></i> <?= __('Profile');?></a>
                          <div class="dropdown-divider brutal-divider"></div>
                          <a class="dropdown-item brutal-dropdown-item" href="index.php?p=member&sec=bookmark"><i class="fas fa-bookmark mr-2"></i> <?= __('Bookmark');?></a>
                          <div class="dropdown-divider brutal-divider"></div>
                          <a class="dropdown-item brutal-dropdown-item text-danger" href="index.php?p=member&logout=1"><i class="fas fa-sign-out-alt mr-2"></i> <?= __('Logout'); ?></a>
                      </div>
                  </li>
              <?php } else { ?>
                  <li class="nav-item m-1">
                      <a class="nav-link brutal-nav-btn brutal-btn-cyan <?= $menu_member_active; ?>" href="index.php?p=member">
                          <i class="fas fa-id-badge mr-1"></i> <?= __('Member Area') ?>
                      </a>
                  </li>
              <?php } ?>

                <li class="nav-item dropdown m-1">
                  <?php
                  $langstr = '';
                  $current_lang = '';
                  $select_lang = isset($_COOKIE['select_lang'])?$_COOKIE['select_lang']:$sysconf['default_lang'];
                  foreach ($available_languages??[] AS $lang_index) {
                    $lang_code = $lang_index[0];
                    $lang_name = $lang_index[1];
                    $code_arr = explode('_', $lang_code);
                    $code_flag = strtolower($code_arr[1] ?? 'id');
                    if ($lang_code == $select_lang) {
                      $current_lang = [
                        'name' => $lang_name,
                        'code' => $code_flag
                      ];
                    }
                    $langstr .= <<<HTML
        <a class="dropdown-item brutal-dropdown-item" href="index.php?select_lang={$lang_code}">
            <span class="flag-icon flag-icon-{$code_flag} mr-2"></span> {$lang_name}
        </a>
HTML;
                  }
                  ?>
                    <a class="nav-link dropdown-toggle brutal-nav-btn brutal-btn-yellow cursor-pointer" type="button" id="languageMenuButton"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="flag-icon flag-icon-<?= $current_lang['code'] ?? 'id' ?> mr-1"></span> <?= strtoupper($current_lang['code'] ?? 'ID') ?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right brutal-dropdown" aria-labelledby="languageMenuButton">
                        <h6 class="dropdown-header brutal-dropdown-header"><?= __('Select Language'); ?></h6>
                      <?= $langstr; ?>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
