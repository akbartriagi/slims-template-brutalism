<?php
/**
 * @Created by          : Waris Agung Widodo (ido.alit@gmail.com)
 * @Date                : 2019-01-29 10:43
 * @File name           : _other.php
 * @Modified for        : Neo-Brutalism Theme
 */

$is_librarian_login = (isset($_GET['p']) && $_GET['p'] === 'login');
?>

<?php if ($is_librarian_login): ?>

<div class="page-librarian-login brutal-librarian-login-page pb-5">
    <section id="section1 container-fluid">
        <header class="c-header brutal-header">
          <?php include '_navbar.php'; ?>
        </header>
    </section>

    <div class="container my-5">
        <div class="row">
            <div class="col-lg-5 col-md-7 col-sm-10 mx-auto">
                <div class="brutal-librarian-login-card">

                    <!-- Card Body -->
                    <div class="p-4 p-md-5 bg-white">
                        <div class="brutal-login-title-box mb-4 pb-3 border-bottom-black">
                            <div class="d-flex align-items-center">
                                <div>
                                    <h2 class="brutal-heading-h2 m-0"><?= __('Librarian Login'); ?></h2>
                                    <div class="text-muted small font-mono font-weight-bold">ADMIN & CIRCULATION SYSTEM</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="brutal-librarian-form-wrap">
                            <?php echo $main_content; ?>
                        </div>

                        <div class="brutal-login-help-box mt-4 p-3 border-black">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-shield-alt fa-2x text-dark mr-3 flex-shrink-0"></i>
                                <div class="text-sm">
                                    <strong>Area Khusus Pustakawan</strong>
                                    <div class="text-muted small">Hanya untuk staf perpustakaan berwenang dalam mengelola katalog, sirkulasi, dan sistem.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php else: ?>

<div class="result-search pb-5">
    <section id="section1 container-fluid">
        <header class="c-header brutal-header">
          <?php
          // ----------------------------------------------------------------------
          // include navbar part
          // ----------------------------------------------------------------------
          include '_navbar.php'; ?>
        </header>
      <?php
      // ------------------------------------------------------------------------
      // include search form part
      // ------------------------------------------------------------------------
      include '_search-form.php'; ?>
    </section>

    <section class="container mt-4 mb-5">
      <?php
      if ($_GET['p'] !== 'show_detail') {
        echo '<div class="brutal-section-box p-4 p-md-5">';
        echo '<div class="brutal-section-header mb-4 pb-2 border-bottom-black d-flex flex-wrap justify-content-between align-items-center">';
        echo '<h2 class="brutal-heading-h3 m-0">' . $page_title . '</h2>';
        if ($_GET['p'] === 'librarian') {
          echo '';
        }
        echo '</div>';
        if ($_GET['p'] === 'librarian') {
          echo '<div class="brutal-librarian-grid">' . $main_content . '</div>';
        } else {
          echo '<div class="brutal-page-content">' . $main_content . '</div>';
        }
        echo '</div>';
      } else {
        echo $main_content;
      }
      ?>
    </section>
</div>

<?php endif; ?>
