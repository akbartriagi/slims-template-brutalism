<!--
# ===============================
# Classic SLiMS Template
# ===============================
# @Author: Waris Agung Widodo
# @Email:  ido.alit@gmail.com
# @Date:   2018-01-23T11:25:57+07:00
# @Last modified by:   Waris Agung Widodo
# @Last modified time: 2019-01-03T11:25:57+07:00
-->
<?php
// clean request uri from xss
$request_uri = urlencode(strip_tags(urldecode($_SERVER['REQUEST_URI'])));
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $page_title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Pragma" content="no-cache"/>
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, post-check=0, pre-check=0"/>
    <meta http-equiv="Expires" content="Sat, 26 Jul 1997 05:00:00 GMT"/>
    <?php echo $metadata;?>
    <?php if (isset($_GET['p']) && ($_GET['p'] == 'show_detail')): ?>
        <meta name="description" content="<?php echo substr($notes, 0, 152) . '...'; ?>">
        <meta name="keywords" content="<?php echo $subject; ?>">
    <?php else: ?>
        <meta name="description" content="<?php echo $page_title; ?>">
        <meta name="keywords" content="<?php echo $sysconf['library_subname']; ?>">
    <?php endif; ?>
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
    <meta name="generator" content="<?php echo SENAYAN_VERSION ?>">
    <meta name="theme-color" content="#000">

    <meta property="og:locale" content="<?php echo str_replace('-', '_', $sysconf['default_lang']); ?>"/>
    <meta property="og:type" content="book"/>
    <meta property="og:title" content="<?php echo $page_title; ?>"/>
    <?php if (isset($_GET['p']) && ($_GET['p'] == 'show_detail')): ?>
        <meta property="og:description" content="<?php echo substr($notes, 0, 152) . '...'; ?>"/>
    <?php else: ?>
        <meta property="og:description" content="<?php echo $sysconf['library_subname']; ?>"/>
    <?php endif; ?>
    <meta property="og:url" content="//<?php echo $_SERVER["SERVER_NAME"] . $request_uri; ?>"/>
    <meta property="og:site_name" content="<?php echo $sysconf['library_name']; ?>"/>
    <?php if (isset($_GET['p']) && ($_GET['p'] == 'show_detail')): ?>
        <meta property="og:image" content="//<?php echo $_SERVER["SERVER_NAME"] . SWB . $image_src ?>"/>
    <?php else: ?>
        <meta property="og:image"
              content="//<?php echo $_SERVER["SERVER_NAME"] . SWB . $sysconf['template']['dir']; ?>/default/img/logo.png"/>
    <?php endif; ?>

    <meta name="twitter:card" content="summary">
    <meta name="twitter:url" content="//<?php echo $_SERVER["SERVER_NAME"] . $request_uri; ?>"/>
    <meta name="twitter:title" content="<?php echo $page_title; ?>"/>
    <?php if (isset($_GET['p']) && ($_GET['p'] == 'show_detail')): ?>
        <meta property="twitter:image" content="//<?php echo $_SERVER["SERVER_NAME"] . SWB . $image_src ?>"/>
    <?php else: ?>
        <meta property="twitter:image"
              content="//<?php echo $_SERVER["SERVER_NAME"] . SWB . $sysconf['template']['dir']; ?>/default/img/logo.png"/>
    <?php endif; ?>
    <!-- // load bootstrap style -->
    <link rel="stylesheet" href="<?php echo assets('css/bootstrap.min.css'); ?>">
    <!-- // font awesome -->
    <link rel="stylesheet" href="<?php echo assets('plugin/font-awesome/css/fontawesome-all.min.css'); ?>">
    <!-- Tailwind CSS -->
    <link rel="stylesheet" href="<?php echo assets('css/tailwind.min.css'); ?>">
    <!-- Vegas CSS -->
    <link rel="stylesheet" href="<?php echo assets('plugin/vegas/vegas.min.css'); ?>">
    <link href="<?php echo JWB; ?>toastr/toastr.min.css?<?php echo date('this') ?>" rel="stylesheet" type="text/css"/>
    <!-- CKEditor5 CSS -->
    <link rel="stylesheet" href="<?= JWB; ?>ckeditor5/ckeditor5.css">
    <!-- SLiMS CSS -->
    <link rel="stylesheet" href="<?= JWB; ?>colorbox/colorbox.css">
    <link rel="stylesheet" href="<?= JWB; ?>ion.rangeSlider/css/ion.rangeSlider.min.css">
    <!-- // Flag css -->
    <link rel="stylesheet" href="<?php echo assets('css/flag-icon.min.css'); ?>">
    <!-- Google Fonts for Brutalism -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Space+Grotesk:wght@600;700;800&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    <!-- // my custom style -->
    <link rel="stylesheet" href="<?php echo assets('css/style.css?v=' . date('Ymd-his')); ?>">

    <?php
    // Neo-Brutalism Dynamic Theme Color & Pattern Settings
    $brutal_accent = $sysconf['template']['brutal_accent_color'] ?? 'yellow';
    $brutal_custom = trim($sysconf['template']['brutal_accent_custom'] ?? '');
    $brutal_pattern = $sysconf['template']['brutal_bg_pattern'] ?? 'dots';
    $brutal_bg = trim($sysconf['template']['brutal_bg_custom'] ?? '');

    $color_palettes = [
        'yellow' => ['main' => '#ffe600', 'alt' => '#ffde59', 'subtle' => '#fffde8'],
        'cyan'   => ['main' => '#00f0ff', 'alt' => '#66f6ff', 'subtle' => '#e8fdff'],
        'pink'   => ['main' => '#ff5c8d', 'alt' => '#ff85ab', 'subtle' => '#fff0f5'],
        'lime'   => ['main' => '#00e599', 'alt' => '#46f1b8', 'subtle' => '#e9fff6'],
        'orange' => ['main' => '#ff6b00', 'alt' => '#ff8833', 'subtle' => '#fff4eb'],
        'purple' => ['main' => '#b388ff', 'alt' => '#cbb0ff', 'subtle' => '#f5edff'],
        'red'    => ['main' => '#ff3b30', 'alt' => '#ff6259', 'subtle' => '#ffeded'],
        'blue'   => ['main' => '#3b82f6', 'alt' => '#60a5fa', 'subtle' => '#eff6ff'],
    ];

    $isValidHex = function($color) {
        return !empty($color) && preg_match('/^#[0-9a-fA-F]{3,8}$/', $color);
    };

    if ($brutal_accent === 'custom' && $isValidHex($brutal_custom)) {
        $theme_main   = $brutal_custom;
        $theme_alt    = $brutal_custom;
        $theme_subtle = $isValidHex($brutal_bg) ? $brutal_bg : '#fffde8';
    } elseif (isset($color_palettes[$brutal_accent])) {
        $theme_main   = $color_palettes[$brutal_accent]['main'];
        $theme_alt    = $color_palettes[$brutal_accent]['alt'];
        $theme_subtle = $isValidHex($brutal_bg) ? $brutal_bg : $color_palettes[$brutal_accent]['subtle'];
    } else {
        $theme_main   = '#ffe600';
        $theme_alt    = '#ffde59';
        $theme_subtle = $isValidHex($brutal_bg) ? $brutal_bg : '#fffde8';
    }

    $bg_pattern_css = '';
    switch ($brutal_pattern) {
        case 'grid':
            $bg_pattern_css = 'background-image: linear-gradient(to right, rgba(0,0,0,0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,0,0,0.08) 1px, transparent 1px) !important; background-size: 24px 24px !important;';
            break;
        case 'stripes':
            $bg_pattern_css = 'background-image: repeating-linear-gradient(45deg, rgba(0, 0, 0, 0.04), rgba(0, 0, 0, 0.04) 10px, transparent 10px, transparent 20px) !important; background-size: auto !important;';
            break;
        case 'cross':
            $bg_pattern_css = 'background-image: radial-gradient(circle, rgba(0,0,0,0.12) 1.5px, transparent 1.5px), radial-gradient(circle, rgba(0,0,0,0.12) 1.5px, transparent 1.5px) !important; background-position: 0 0, 14px 14px !important; background-size: 28px 28px !important;';
            break;
        case 'none':
            $bg_pattern_css = 'background-image: none !important;';
            break;
        case 'dots':
        default:
            $bg_pattern_css = 'background-image: radial-gradient(rgba(0, 0, 0, 0.15) 1.2px, transparent 1.2px) !important; background-size: 24px 24px !important;';
            break;
    }
    ?>
    <style id="brutal-theme-customizer">
        :root {
            --brutal-yellow: <?= $theme_main ?> !important;
            --brutal-yellow-alt: <?= $theme_alt ?> !important;
            --brutal-bg: <?= $theme_subtle ?> !important;
        }
        body.brutal-body, body {
            background-color: var(--brutal-bg) !important;
            <?= $bg_pattern_css ?>
        }
    </style>

    <?php
    $icon = SWB . 'webicon.ico';
    if (isset($sysconf['webicon']) && !empty($sysconf['webicon']) && $imagesDisk->isExists($path = 'default/' . $sysconf['webicon']))
    {
        $icon = SWB . 'lib/minigalnano/createthumb.php?filename=images/' . $path . '&width=130';
    }
    ?>
    <link rel="shortcut icon" href="<?= $icon ?>" type="image/x-icon"/>

    <!-- // load vue js -->
    <script src="<?php echo assets('js/vue.min.js'); ?>"></script>
    <!-- // load jquery library -->
    <script src="<?php echo assets('js/jquery.min.js'); ?>"></script>
    <script src="<?php echo assets('js/masonry.pkgd.min.js'); ?>"></script>
    <!-- // load bootstrap javascript -->
    <script src="<?php echo assets('js/bootstrap.bundle.min.js'); ?>"></script>
    <!-- // load vegas javascript -->
    <script src="<?php echo assets('plugin/vegas/vegas.min.js'); ?>"></script>
    <script src="<?php echo JWB; ?>toastr/toastr.min.js"></script>
    <!-- // load SLiMS javascript -->
    <script src="<?php echo JWB; ?>colorbox/jquery.colorbox-min.js"></script>
    <script src="<?php echo JWB . v('gui.js'); ?>"></script>
    <script src="<?php echo JWB; ?>fancywebsocket.js"></script>
    <script src="<?php echo JWB; ?>ion.rangeSlider/js/ion.rangeSlider.min.js"></script>
    <?php
    if (isset($js)):
        echo $js;
    endif;
    ?>

</head>
<body class="brutal-body">
