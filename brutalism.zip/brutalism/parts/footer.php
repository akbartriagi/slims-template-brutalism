<?php
# @Author: Waris Agung Widodo <user>
# @Date:   2018-01-23T11:26:05+07:00
# @Email:  ido.alit@gmail.com
# @Filename: footer.php
# @Last modified time: 2026-10-18T20:33:00+07:00
?>

<footer class="brutal-footer text-white">
    <!-- Top Decorative Checkerboard/Stripe Line -->
    <div class="brutal-footer-strip"></div>

    <div class="container py-5">
        <div class="row">
            <!-- Col 1: Library Brand & Links -->
            <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                <div class="brutal-footer-brand mb-3">
                    <h4 class="brutal-footer-title m-0"><?php echo $sysconf['library_name']; ?></h4>
                </div>

                <ul class="list-unstyled brutal-footer-links mt-3">
                    <li><a href="index.php?p=libinfo"><span class="mr-2">»</span><?= __('Information'); ?></a></li>
                    <li><a href="index.php?p=services"><span class="mr-2">»</span><?= __('Services'); ?></a></li>
                    <li><a href="index.php?p=librarian"><span class="mr-2">»</span><?= __('Librarian'); ?></a></li>
                    <li><a href="index.php?p=member"><span class="mr-2">»</span><?= __('Member Area'); ?></a></li>
                </ul>
            </div>

            <!-- Col 2: About Us -->
            <div class="col-lg-5 col-md-6 mb-4 mb-lg-0">
                <div class="brutal-footer-box mb-3">
                    <span class="brutal-footer-box-tag">ABOUT US</span>
                    <h5 class="brutal-footer-subtitle mt-2 mb-3"><?= __('About Us'); ?></h5>
                    <div class="brutal-footer-text">
                        <?= $sysconf['template']['classic_footer_about_us']; ?>
                    </div>
                </div>
            </div>

            <!-- Col 3: Fast Search & Community Links -->
            <div class="col-lg-4 col-md-12">
                <div class="brutal-footer-search-box">
                    <span class="brutal-footer-box-tag brutal-tag-yellow">CATALOG SEARCH</span>
                    <h5 class="brutal-footer-subtitle text-dark mt-2 mb-2"><?= __('Quick Find'); ?></h5>
                    <p class="text-dark small mb-3"><?= __('start it by typing one or more keywords for title, author or subject'); ?></p>
                    
                    <form action="index.php" method="get">
                        <input type="hidden" ref="csrf_token" value="<?= $_SESSION['csrf_token']??'' ?>">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']??'' ?>">
                        <div class="input-group brutal-footer-input-group mb-3">
                            <input name="keywords" type="text" class="form-control brutal-footer-input"
                                   placeholder="<?= __('Enter keywords'); ?>..."
                                   aria-label="Enter keywords">
                            <div class="input-group-append">
                                <button class="btn brutal-footer-btn" type="submit" value="search" name="search">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="brutal-footer-actions d-flex flex-wrap mt-2">
                        <a target="_blank" title="Support Us" class="btn brutal-action-btn brutal-btn-lime mr-2 mb-2"
                           href="https://slims.web.id/web/pages/support-us/">
                            <i class="fas fa-heart mr-1"></i> <?= __('Keep SLiMS Alive'); ?>
                        </a>
                        <a target="_blank" title="Contribute" class="btn brutal-action-btn brutal-btn-cyan mb-2"
                           href="https://github.com/slims/">
                            <i class="fab fa-github mr-1"></i> <?= __('Want to Contribute?'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="brutal-footer-bottom mt-5 pt-3 d-flex flex-column flex-md-row justify-content-between align-items-center">
            <p class="m-0 text-white font-mono small">
                &copy; <?php echo date('Y'); ?> &bull; <strong><?php echo $sysconf['library_name']; ?></strong> &mdash; Senayan Developer Community
            </p>
            <div class="mt-2 mt-md-0 font-mono small">
                <span>POWERED BY </span><strong class="brutal-slims-badge">SLiMS 9 BULIAN</strong>
            </div>
        </div>
    </div>
</footer>

<?php if ($sysconf['chat_system']['enabled'] && $sysconf['chat_system']['opac']) : ?>
    <div id="show-pchat2" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;" class="brutal-chat-btn-wrap">
        <button title="Chat" class="btn brutal-btn-chat"><i class="fas fa-comments mr-2"></i><?= __('Chat'); ?></button>
    </div>
<?php endif; ?>

<?php
// Chat Engine
include LIB . "contents/chat.php"; ?>

<!-- // Load modal -->
<?php include "_modal_topic.php"; ?>
<?php include "_modal_advanced.php"; ?>
<?php include "_modal_social_media.php"; ?>

<!-- // Load highlight -->
<script src="<?= JWB; ?>highlight.js"></script>
<?php if(isset($engine) && $searchableInJsArray = $this->generateKeywords($engine->searchable_fields)) : ?>
<script>
  $('.card-body > *').highlight(<?= $searchableInJsArray ?>);
</script>
<?php endif; ?>

<!-- // load our vue app.js -->
<script src="<?php echo assets('js/app.js?v=' . filemtime(__DIR__ . '/../assets/js/app.js')); ?>"></script>
<script src="<?php echo assets('js/app_jquery.js?v=' . filemtime(__DIR__ . '/../assets/js/app_jquery.js')); ?>"></script>
<?php include __DIR__ . "/../assets/js/vegas.js.php"; ?>
<?php if ($sysconf['chat_system']['enabled'] && $sysconf['chat_system']['opac']) : ?>
    <script>
        $('#show-pchat').click(() => {
            $('.s-chat').hide()
            $('#show-pchat2').show()
        })
        $('#show-pchat2').click(() => {
            $('.s-chat').show(300, () => {
                $('#show-pchat2').hide()
            })
        })
    </script>
<?php endif; ?>
</body>
</html>
