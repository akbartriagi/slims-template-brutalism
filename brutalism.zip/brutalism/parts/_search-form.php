<?php
# @Author: Waris Agung Widodo <user>
# @Date:   2018-01-25T10:31:54+07:00
# @Email:  ido.alit@gmail.com
# @Filename: _search-form.php
# @Last modified time: 2026-10-18T20:31:00+07:00

if ($opac->invalid_token) {
    //die($opac->error('invalid CSRF token'));
}
?>

<div class="search brutal-search-section" id="search-wraper" xmlns:v-bind="http://www.w3.org/1999/xhtml">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 mx-auto">
                <!-- Brutalist Search Box -->
                <div class="brutal-search-card">
                    <form class="brutal-search-form d-flex align-items-center" action="index.php" method="get" @submit.prevent="searchSubmit">
                        <input type="hidden" name="search" value="search">
                        <div class="brutal-input-wrapper flex-grow-1">
                            <input ref="keywords" value="<?= htmlentities(getQuery('keywords')) ?>" v-model.trim="keywords"
                                   @focus="searchOnFocus" @blur="searchOnBlur" type="text" id="search-input"
                                   name="keywords" class="brutal-search-input w-100" autocomplete="off"
                                   placeholder="<?= __('Enter keyword to search collection...');?>"/>
                        </div>
                        <button type="submit" class="brutal-search-btn" title="Cari Sekarang">
                            <span class="d-none d-sm-inline mr-1">SEARCH</span> <i class="fas fa-arrow-right"></i>
                        </button>
                    </form>
                </div>

                <!-- Advanced & Quick Search Filter Dropdown -->
                <transition name="slide-fade">
                    <div v-if="show" class="advanced-wraper brutal-advanced-box mt-3" id="advanced-wraper"
                         v-click-outside="hideSearch">
                        <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom-black">
                            <span class="brutal-box-title">
                                <i class="fas fa-filter mr-1"></i> <?= __('Search by :');?>
                            </span>
                            <button type="button" @click="hideSearch" class="brutal-close-pill" title="Tutup">
                                [ ESC ✕ ]
                            </button>
                        </div>
                        <div class="d-flex flex-wrap align-items-center">
                            <a v-bind:class="{'brutal-filter-active': searchBy === 'keywords', 'brutal-filter-btn': searchBy !== 'keywords' }"
                               @click="searchOnClick('keywords')" class="btn mr-2 mb-2"><?= __('ALL')?></a>
                            <a v-bind:class="{'brutal-filter-active': searchBy === 'author', 'brutal-filter-btn': searchBy !== 'author' }"
                               @click="searchOnClick('author')" class="btn mr-2 mb-2"><?= __('Author');?></a>
                            <a v-bind:class="{'brutal-filter-active': searchBy === 'subject', 'brutal-filter-btn': searchBy !== 'subject' }"
                               @click="searchOnClick('subject')" class="btn mr-2 mb-2"><?= __('Subject');?></a>
                            <a v-bind:class="{'brutal-filter-active': searchBy === 'isbn', 'brutal-filter-btn': searchBy !== 'isbn' }"
                               @click="searchOnClick('isbn')" class="btn mr-2 mb-2"><?= __('ISBN/ISSN');?></a>
                            <span class="brutal-or-badge mr-2 mb-2">OR</span>
                            <a class="btn brutal-adv-btn mr-2 mb-2" data-toggle="modal" data-target="#adv-modal">
                                <i class="fas fa-sliders-h mr-1"></i> <?= __('Advanced Search');?>
                            </a>
                        </div>
                        <div v-if="lastKeywords.length > 0" class="mt-3 pt-2 border-top-black">
                            <span class="brutal-label-sub mb-2 d-block"><?= __('Last search:');?></span>
                            <div class="d-flex flex-wrap">
                                <a :href="`index.php?${tmpObj[k].searchBy}=${tmpObj[k].text}&search=search`"
                                   class="brutal-history-tag mr-2 mb-2"
                                   v-for="k in lastKeywords" :key="k">
                                    <i class="far fa-clock mr-1"></i>{{tmpObj[k].text}}
                                </a>
                            </div>
                        </div>
                    </div>
                </transition>
            </div>
        </div>
    </div>
</div>
