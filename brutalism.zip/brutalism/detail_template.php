<?php
/**
 * @Created by          : Waris Agung Widodo (ido.alit@gmail.com)
 * @Date                : 2019-01-30 00:58
 * @File name           : detail_template.php
 * @Modified for        : Neo-Brutalism Theme
 */
$setBookmarked = trim(isset($_SESSION['bookmark'][$biblio_id]) ? 'brutal-btn-pink text-white' : 'brutal-btn-yellow text-dark');
?>

<div class="container my-5">
    <div class="brutal-detail-card p-4 p-md-5">
        <div class="row">
            <!-- Left Column: Cover & Actions -->
            <div class="col-md-4 col-lg-3 mb-4 mb-md-0">
                <div class="brutal-cover-wrapper mb-3 text-center">
                    <div class="brutal-cover-inner">
                        <?= $image; ?>
                    </div>
                </div>
                <div class="d-flex flex-column justify-content-center">
                    <a href="#" data-id="<?= $biblio_id ?>" data-detail="true" class="bookMarkBook btn brutal-nav-btn <?= $setBookmarked ?> font-weight-bolder mb-2 text-center justify-content-center">
                        <i class="fas fa-bookmark mr-2"></i>
                        <?= in_array($biblio_id, $_SESSION['bookmark']??[]) ? __('Bookmarked') : __('Bookmark') ?>
                    </a>
                    <a href="javascript:void(0)" data-toggle="modal" data-id="<?= $biblio_id ?>" data-title="<?= $title ?>" data-target="#mediaSocialModal" class="btn brutal-nav-btn brutal-btn-cyan font-weight-bolder text-center justify-content-center">
                        <i class="fas fa-share-alt mr-2"></i>
                        <?= __('Share') ?>
                    </a>
                </div>
            </div>

            <!-- Right Column: Metadata & Details -->
            <div class="col-md-8 col-lg-9 pl-md-4">
                <div class="d-flex align-items-center mb-2">
                    <span class="brutal-badge-pill brutal-pill-cyan mr-2">[ GMD: <?= strtoupper($gmd_name); ?> ]</span>
                    <?php if (!empty($call_number)): ?>
                    <span class="brutal-code-stamp"><?= $call_number; ?></span>
                    <?php endif; ?>
                </div>

                <h2 class="brutal-heading-h3 mb-2"><?= stripslashes($title); ?></h2>
                <div class="brutal-author-bar mb-3">
                    <span class="font-weight-bold"><?= __('Author(s)'); ?>:</span>
                    <span class="brutal-author-name ml-1"><?= str_replace("<br />", '; ', $authors); ?></span>
                </div>

                <div class="brutal-notes-box p-3 mb-4">
                    <span class="brutal-label-tag mb-2 d-inline-block">ABSTRACT / DESCRIPTION</span>
                    <p class="m-0 text-dark">
                        <?= $notes ? $notes : '<i>'.__('Description Not Available').'</i>'; ?>
                    </p>
                </div>

                <!-- Availability Section -->
                <div class="brutal-availability-box p-3 mb-4">
                    <h5 class="brutal-subhead mb-2"><i class="fas fa-boxes mr-1"></i> <?= __('Availability'); ?></h5>
                    <div class="brutal-avail-content">
                        <?= ($availability) ? $availability : '<p class="text-danger font-weight-bold m-0">' . __('No copy data') . '</p>'; ?>
                    </div>
                </div>

                <!-- Detailed Specs -->
                <div class="brutal-specs-table">
                    <h5 class="brutal-subhead mb-3"><i class="fas fa-info-circle mr-1"></i> <?= __('Detail Information'); ?></h5>
                    <dl class="row brutal-dl">
                        <dt class="col-sm-4"><?= __('Series Title'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($series_title) ? $series_title : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Call Number'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($call_number) ? $call_number : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Publisher'); ?></dt>
                        <dd class="col-sm-8">
                            <?php echo $publish_place ?> : <?php echo $publisher_name ?>., <?php echo $publish_year ?>
                        </dd>

                        <dt class="col-sm-4"><?= __('Collation'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($collation) ? $collation : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Language'); ?></dt>
                        <dd class="col-sm-8"><?php echo $language_name; ?></dd>

                        <dt class="col-sm-4"><?= __('ISBN/ISSN'); ?></dt>
                        <dd class="col-sm-8 font-mono"><?php echo ($isbn_issn) ? $isbn_issn : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Classification'); ?></dt>
                        <dd class="col-sm-8 font-mono"><?php echo ($classification) ? $classification : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Content Type'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($content_type) ? $content_type : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Media Type'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($media_type) ? $media_type : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Carrier Type'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($carrier_type) ? $carrier_type : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Edition'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($edition) ? $edition : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Subject(s)'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($subjects) ? $subjects : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Specific Detail Info'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($spec_detail_info) ? $spec_detail_info : '-'; ?></dd>

                        <dt class="col-sm-4"><?= __('Statement of Responsibility'); ?></dt>
                        <dd class="col-sm-8"><?php echo ($sor) ? $sor : '-'; ?></dd>
                    </dl>
                </div>

                <?php if ($file_att): ?>
                <div class="brutal-attachment-box mt-4 p-3">
                    <h5 class="brutal-subhead mb-2"><i class="fas fa-paperclip mr-1"></i> <?= __('File Attachment'); ?></h5>
                    <?= $file_att; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
